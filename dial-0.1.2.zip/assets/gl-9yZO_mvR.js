var e=e=>Math.min(1,Math.max(0,+e||0));function t(e,t=2){let n=Math.min(t,typeof window<`u`&&window.devicePixelRatio||1),r=Math.max(1,Math.round(e.clientWidth*n)),i=Math.max(1,Math.round(e.clientHeight*n));return(e.width!==r||e.height!==i)&&(e.width=r,e.height=i),{w:r,h:i}}function n(){try{return typeof matchMedia<`u`&&matchMedia(`(prefers-reduced-motion: reduce)`).matches}catch{return!1}}function r(r){let i=r.getContext(`webgl2`,{antialias:!1,alpha:!1,depth:!1,stencil:!1,powerPreference:`high-performance`});if(!i)throw Error(`webgl2 unavailable`);let a=(e,t)=>{let n=i.createShader(e);if(i.shaderSource(n,t),i.compileShader(n),!i.getShaderParameter(n,i.COMPILE_STATUS)){let e=i.getShaderInfoLog(n);throw i.deleteShader(n),Error(`shader compile failed: `+e)}return n},o=i.createProgram();if(i.attachShader(o,a(i.VERTEX_SHADER,`
attribute vec2 a_pos;
varying vec2 v_uv;
void main(){
  v_uv = a_pos * 0.5 + 0.5;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`)),i.attachShader(o,a(i.FRAGMENT_SHADER,`
precision highp float;
varying vec2 v_uv;
uniform vec2  u_res;
uniform float u_time;
uniform float u_energy;    // 0..1 audio level + knob velocity
uniform float u_voice;     // 0..1 voice waveform ring
uniform float u_knobGlow;  // 0..1 warm rim glow
uniform float u_bloom;     // 0..1 decaying flash

float hash(vec2 p){
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p){
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p){
  float v = 0.0, a = 0.5;
  for(int i = 0; i < 4; i++){
    v += a * vnoise(p);
    p = p * 2.03 + vec2(17.3, 9.1);
    a *= 0.5;
  }
  return v;
}

void main(){
  // centered coords, display-agnostic (the stage is circular)
  vec2 uv = (gl_FragCoord.xy - 0.5 * u_res) / u_res.y;
  float t = u_time * (0.22 + u_energy * 0.85);

  // domain-warped liquid metal flow (3 fbm evals total — 60fps-safe)
  vec2 q = vec2(fbm(uv * 1.7 + vec2(0.0, t * 0.55)),
                fbm(uv * 1.7 + vec2(5.2, -t * 0.42)));
  float f = fbm(uv * 2.3 + q * 1.7 + vec2(t * 0.12, 0.0));

  // chrome ramp: deep graphite -> brushed silver
  vec3 base = vec3(0.030, 0.032, 0.040);
  vec3 mid  = vec3(0.095, 0.100, 0.125);
  vec3 hi   = vec3(0.72, 0.75, 0.82);
  float m = smoothstep(0.28, 0.86, f);
  float sheen = smoothstep(0.52, 0.95, f);
  vec3 col = mix(base, mid, m);
  col = mix(col, hi, pow(sheen, 3.0) * (0.30 + 0.70 * u_energy));

  // refractive diagonal light streak, bent by the flow field
  float streak = smoothstep(0.035, 0.0,
      abs(uv.x + uv.y * 0.62 - 0.22 + (f - 0.5) * 0.35));
  col += vec3(0.85, 0.92, 1.0) * streak * (0.22 + 0.45 * u_energy);

  // voice waveform ring — alive and musical
  float d = length(uv);
  float ringR = 0.27 + 0.05 * sin(u_time * 3.1) + u_energy * 0.03;
  float ring = smoothstep(0.025, 0.0, abs(d - ringR)) * u_voice;
  col += vec3(1.0, 0.30, 0.05) * ring * 1.35;

  // knob glow: warm light pooling at the rim
  float rim = smoothstep(0.40, 0.50, d);
  col += vec3(1.0, 0.42, 0.12) * rim * u_knobGlow * 0.55;

  // bloom flash (track-start bloom)
  col += vec3(1.0, 0.97, 0.94) * u_bloom * (0.55 + 0.45 * f);

  // circular falloff into the bezel
  col *= 1.0 - smoothstep(0.455, 0.5, d) * 0.9;
  col *= 0.45 + 0.55 * smoothstep(0.52, 0.30, d);

  // OLED grain
  col += (hash(gl_FragCoord.xy * 0.71 + fract(u_time) * 13.7) - 0.5) * 0.038;

  gl_FragColor = vec4(col, 1.0);
}
`)),i.linkProgram(o),!i.getProgramParameter(o,i.LINK_STATUS))throw Error(`program link failed: `+i.getProgramInfoLog(o));i.useProgram(o);let s=i.createBuffer();i.bindBuffer(i.ARRAY_BUFFER,s),i.bufferData(i.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),i.STATIC_DRAW);let c=i.getAttribLocation(o,`a_pos`);i.enableVertexAttribArray(c),i.vertexAttribPointer(c,2,i.FLOAT,!1,0,0);let l=e=>i.getUniformLocation(o,e),u=l(`u_res`),d=l(`u_time`),f=l(`u_energy`),p=l(`u_voice`),m=l(`u_knobGlow`),h=l(`u_bloom`),g={time:Math.random()*100,energy:0,energyT:0,voice:0,voiceT:0,knob:0,knobT:0,bloom:0,reduced:n(),dead:!1};function _(e){if(g.dead)return;e=Math.min(.1,Math.max(0,e||0));let{w:n,h:a}=t(r),o=1-Math.exp(-e*7),s=1-Math.exp(-e*14);g.energy+=(g.energyT-g.energy)*o,g.voice+=(g.voiceT-g.voice)*s,g.knob+=(g.knobT-g.knob)*o,g.bloom*=Math.exp(-e*2.6),g.bloom<.003&&(g.bloom=0),g.time+=e*(g.reduced?.04:1),i.viewport(0,0,n,a),i.uniform2f(u,n,a),i.uniform1f(d,g.time),i.uniform1f(f,g.energy),i.uniform1f(p,g.voice),i.uniform1f(m,g.knob),i.uniform1f(h,g.bloom),i.drawArrays(i.TRIANGLES,0,3)}function v(){g.dead=!0;try{let e=i.getExtension(`WEBGL_lose_context`);e&&e.loseContext()}catch{}}return{setEnergy(t){g.energyT=e(t)},setVoiceLevel(t){g.voiceT=e(t)},setKnobGlow(t){g.knobT=e(t)},bloom(t=1){g.bloom=Math.max(g.bloom,e(t))},tick:_,dispose:v}}function i(r){let i=r.getContext(`2d`);if(!i)throw Error(`2d context unavailable`);let a={time:0,energy:0,energyT:0,voice:0,voiceT:0,knob:0,knobT:0,bloom:0,reduced:n(),dead:!1},o=Math.PI*2;function s(e){if(a.dead)return;e=Math.min(.1,Math.max(0,e||0));let{w:n,h:s}=t(r,1.5),c=1-Math.exp(-e*7),l=1-Math.exp(-e*14);a.energy+=(a.energyT-a.energy)*c,a.voice+=(a.voiceT-a.voice)*l,a.knob+=(a.knobT-a.knob)*c,a.bloom*=Math.exp(-e*2.6),a.bloom<.003&&(a.bloom=0),a.time+=e*(a.reduced?.04:1);let u=n/2,d=s/2,f=Math.min(n,s)/2;i.fillStyle=`#08080b`,i.fillRect(0,0,n,s);for(let e=0;e<9;e++){let t=e/9,n=f*(.1+.88*t)*(1+.055*Math.sin(a.time*(.5+t*1.3)+e*2.4)*(.35+a.energy)),r=a.time*(.12+t*.25)*(e%2?1:-1)+e,s=o*(.35+.5*t),c=Math.round(14+90*t*(.5+.5*a.energy));i.beginPath(),i.arc(u,d,Math.max(1,n),r,r+s),i.strokeStyle=`rgba(${c},${c+4},${c+12},${.16+.5*t})`,i.lineWidth=1+7*t*(.4+.6*a.energy),i.stroke()}if(a.voice>.01){let e=f*(.3+.05*Math.sin(a.time*3.1));i.beginPath(),i.arc(u,d,e,0,o),i.strokeStyle=`rgba(255,77,0,${.85*a.voice})`,i.lineWidth=3,i.stroke(),i.beginPath(),i.arc(u,d,e*1.12,0,o),i.strokeStyle=`rgba(255,77,0,${.25*a.voice})`,i.lineWidth=8,i.stroke()}if(a.knob>.01){let e=i.createRadialGradient(u,d,f*.72,u,d,f);e.addColorStop(0,`rgba(255,77,0,0)`),e.addColorStop(1,`rgba(255,110,20,${.35*a.knob})`),i.fillStyle=e,i.fillRect(0,0,n,s)}a.bloom>0&&(i.fillStyle=`rgba(255,250,244,${.55*a.bloom})`,i.fillRect(0,0,n,s));let p=i.createRadialGradient(u,d,f*.55,u,d,f);p.addColorStop(0,`rgba(0,0,0,0)`),p.addColorStop(1,`rgba(0,0,0,0.55)`),i.fillStyle=p,i.fillRect(0,0,n,s)}return{setEnergy(t){a.energyT=e(t)},setVoiceLevel(t){a.voiceT=e(t)},setKnobGlow(t){a.knobT=e(t)},bloom(t=1){a.bloom=Math.max(a.bloom,e(t))},tick:s,dispose(){a.dead=!0}}}function a(e){if(!e||typeof e.getContext!=`function`)throw Error(`initGL needs a canvas element`);try{return r(e)}catch{try{return i(e)}catch(e){throw Error(`no renderable context: `+e.message)}}}export{a as initGL};